package com.example.phlo.myapplication.Banco;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;
import android.util.Log;

import com.example.phlo.myapplication.Model.LivroModel;
import com.example.phlo.myapplication.Model.ParticipanteModel;
import com.example.phlo.myapplication.Model.ReservaModel;

import java.io.ObjectStreamException;
import java.util.concurrent.ExecutionException;

/**
 * Created by phlo on 08/12/17.
 */

public class BibliotecaDbHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 4;
    public static final String DATABASE_NAME = "Biblioteca.db";

    public BibliotecaDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(BibliotecaContract.SQL_CREATE_LIVRO);
        sqLiteDatabase.execSQL(BibliotecaContract.SQL_CREATE_PARTICIPANTE);
        sqLiteDatabase.execSQL(BibliotecaContract.SQL_CREATE_Reserva);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(BibliotecaContract.SQL_DROP_LIVRO);
        sqLiteDatabase.execSQL(BibliotecaContract.SQL_DROP_PARTICIPANTE);
        sqLiteDatabase.execSQL(BibliotecaContract.SQL_DROP_Reserva);
        onCreate(sqLiteDatabase);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    private ContentValues getContentValues(Object objeto) {
        ContentValues values = new ContentValues();
        if (objeto instanceof LivroModel) {
            LivroModel livro = (LivroModel) objeto;
            if (!TextUtils.isEmpty(livro.getTitulo())) {
                values.put(BibliotecaContract.Livro.COLUMN_NAME_TITULO, livro.getTitulo());
            }
            if (!TextUtils.isEmpty(livro.getEditora())) {
                values.put(BibliotecaContract.Livro.COLUMN_NAME_EDITORA, livro.getEditora());
            }
            if (!TextUtils.isEmpty(String.valueOf(livro.getAno()))) {
                values.put(BibliotecaContract.Livro.COLUMN_NAME_ANO, livro.getAno());

            }
        } else if (objeto instanceof ParticipanteModel) {
            ParticipanteModel participante = (ParticipanteModel) objeto;
            if (!TextUtils.isEmpty(participante.getNome())) {
                values.put(BibliotecaContract.Participante.COLUMN_NAME_NOME, participante.getNome());
            }
            if (!TextUtils.isEmpty(participante.getEmail())) {
                values.put(BibliotecaContract.Participante.COLUMN_NAME_EMAIL, participante.getEmail());

            }
            values.put(BibliotecaContract.Participante.COLUMN_NAME_ENTRADA,"");
            values.put(BibliotecaContract.Participante.COLUMN_NAME_SAIDA,"");
        } else if (objeto instanceof ReservaModel) {
                ReservaModel reserva = (ReservaModel) objeto;
                if (!TextUtils.isEmpty(reserva.getLivronome())) {
                    values.put(BibliotecaContract.Reserva.COLUMN_NAME_TITULOLIVRO, reserva.getLivronome());
                }
                if (!TextUtils.isEmpty(reserva.getParticipantesnome())) {
                    values.put(BibliotecaContract.Reserva.TABLE_NAME, reserva.getParticipantesnome());
                }
            }
        return values;
        }
        /*else if(objeto instanceof ReservaModel){
            ReservaModel reserva=(ReservaModel)objeto;
            (!TextUtils.isEmpty(reserva.getParticipantes().get)){
                values.put(BibliotecaContract.Participante.COLUMN_NAME_NOME,participante.getNome());
            }
            if(!TextUtils.isEmpty(reserva.getEmail())){
                values.put(BibliotecaContract.Participante.COLUMN_NAME_EMAIL,participante.getEmail());
            }
        }*/



    public void salvar(Object objeto) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = getContentValues(objeto);
        if (objeto instanceof LivroModel){
            db.insert(BibliotecaContract.Livro.TABLE_NAME, null, values);
            atualizaParticipantes();}
        else if (objeto instanceof ParticipanteModel) {
            db.insert(BibliotecaContract.Participante.TABLE_NAME, null, values);
            atualizaLivro();
        }
        else if (objeto instanceof ReservaModel) {
            db.insert(BibliotecaContract.Reserva.TABLE_NAME, null, values);

        }
        //  database.insert();
        // }

    }

    public void entrada(String entrada, int id) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(BibliotecaContract.Participante.COLUMN_NAME_ENTRADA, entrada);
            String sel = BibliotecaContract.Participante._ID + "=?";
            db.update(BibliotecaContract.Participante.TABLE_NAME, values, sel,
                    new String[]{Integer.toString(id)});
        } catch (Exception e) {
            Log.e("erro", e.getLocalizedMessage());
        }
    }

    public void saida(String entrada, int id) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(BibliotecaContract.Participante.COLUMN_NAME_SAIDA, entrada);
            String sel = BibliotecaContract.Participante._ID + "=?";
            db.update(BibliotecaContract.Participante.TABLE_NAME, values, sel,
                    new String[]{Integer.toString(id)});
        } catch (Exception e) {
            Log.e("erro", e.getLocalizedMessage());

        }


    }

    public String consultaEntrada(int id) {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] visao = {
                    BibliotecaContract.Participante._ID,
                    BibliotecaContract.Participante.COLUMN_NAME_NOME,
                    BibliotecaContract.Participante.COLUMN_NAME_EMAIL,
                    BibliotecaContract.Participante.COLUMN_NAME_ENTRADA,

                    BibliotecaContract.Participante.COLUMN_NAME_SAIDA,


            };
            String selecao = BibliotecaContract.Participante._ID + "=?";
            String []args = {Integer.toString(id)};
            Cursor c = db.query(BibliotecaContract.Participante.TABLE_NAME, visao, selecao, args, null, null, null);
            c.moveToFirst();
            String entrada = c.getString(c.getColumnIndex(BibliotecaContract.Participante.COLUMN_NAME_SAIDA));
            return entrada;

        } catch (Exception e) {
            Log.e("BIBLIO", e.getLocalizedMessage());
            Log.e("BIBLIO", e.getStackTrace().toString());
            return null;
        }

    }

    public String consultaSaida(int id) {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] visao = {
                    BibliotecaContract.Participante._ID,
                    BibliotecaContract.Participante.COLUMN_NAME_NOME,
                    BibliotecaContract.Participante.COLUMN_NAME_EMAIL,
                    BibliotecaContract.Participante.COLUMN_NAME_ENTRADA,

                    BibliotecaContract.Participante.COLUMN_NAME_SAIDA,


            };
            String selecao = BibliotecaContract.Participante._ID + "=?";
            String []args = {Integer.toString(id)};
            Cursor c = db.query(BibliotecaContract.Participante.TABLE_NAME, visao, selecao, args, null, null, null);
            c.moveToFirst();
            String entrada = c.getString(c.getColumnIndex(BibliotecaContract.Participante.COLUMN_NAME_ENTRADA));
            return entrada;

        } catch (Exception e) {
            Log.e("BIBLIO", e.getLocalizedMessage());
            Log.e("BIBLIO", e.getStackTrace().toString());
            return null;
        }

    }

    public ParticipanteModel Participantes(int i) {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] visao = {
                    BibliotecaContract.Participante._ID,
                    BibliotecaContract.Participante.COLUMN_NAME_NOME,
                    BibliotecaContract.Participante.COLUMN_NAME_EMAIL,
                    BibliotecaContract.Participante.COLUMN_NAME_ENTRADA,

                    BibliotecaContract.Participante.COLUMN_NAME_SAIDA,


            };
            String sel = BibliotecaContract.Participante._ID + "=?";
            String arg[] = {Integer.toString(i)};
            Cursor c = db.query(BibliotecaContract.Participante.TABLE_NAME, visao, sel, arg, null, null, null);
            c.moveToFirst();
            ParticipanteModel participante = new ParticipanteModel(c.getString(c.getColumnIndex(BibliotecaContract.Participante.COLUMN_NAME_NOME)),
                    c.getString(c.getColumnIndex(BibliotecaContract.Participante.COLUMN_NAME_EMAIL)
                    ), c.getString(c.getColumnIndex(BibliotecaContract.Participante.COLUMN_NAME_ENTRADA)
            ), c.getString(c.getColumnIndex(BibliotecaContract.Participante.COLUMN_NAME_SAIDA)
            ));
            return participante;
        } catch (Exception e) {
            Log.e("BIBLIO", e.getLocalizedMessage());
            Log.e("BIBLIO", e.getStackTrace().toString());
            return null;
        }
    }

    public ReservaModel reserva(int id) {
        try {
            SQLiteDatabase db = this.getReadableDatabase();

            String[] visao = {
                    BibliotecaContract.Reserva._ID,
                    BibliotecaContract.Reserva.COLUMN_NAME_NomeParticipante,
                    BibliotecaContract.Reserva.COLUMN_NAME_TITULOLIVRO


            };
            String selecao = BibliotecaContract.Reserva._ID + "=?";
            String arg[] = {Integer.toString(id)};
            Cursor c = db.query(BibliotecaContract.Reserva.TABLE_NAME, visao, selecao, arg, null, null, null);
            c.moveToFirst();
            ReservaModel entrada = new ReservaModel(c.getString(c.getColumnIndex(BibliotecaContract.Reserva.COLUMN_NAME_TITULOLIVRO))
                    , c.getString(c.getColumnIndex(BibliotecaContract.Reserva.COLUMN_NAME_TITULOLIVRO))
            );
            return entrada;

        } catch (Exception e) {
            Log.e("BIBLIO", e.getLocalizedMessage());
            Log.e("BIBLIO", e.getStackTrace().toString());
            return null;
        }

    }
    public Cursor atualizaParticipantes(){
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] visao = {
                    BibliotecaContract.Participante._ID,
                    BibliotecaContract.Participante.COLUMN_NAME_NOME,
                    BibliotecaContract.Participante.COLUMN_NAME_EMAIL,
                    BibliotecaContract.Participante.COLUMN_NAME_ENTRADA,
                    BibliotecaContract.Participante.COLUMN_NAME_SAIDA,


            };

            Cursor c = db.query(BibliotecaContract.Participante.TABLE_NAME, visao, null, null, null, null, null);
            return c;

        } catch (Exception e) {
            Log.e("BIBLIO", e.getLocalizedMessage());
            Log.e("BIBLIO", e.getStackTrace().toString());
            return  null;
        }
    }
    public Cursor atualizaLivro(){

        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] visao = {
                    BibliotecaContract.Livro._ID,
                    BibliotecaContract.Livro.COLUMN_NAME_TITULO,
                    BibliotecaContract.Livro.COLUMN_NAME_EDITORA,
                    BibliotecaContract.Livro.COLUMN_NAME_ANO

            };

            Cursor c = db.query(BibliotecaContract.Livro.TABLE_NAME, visao, null, null, null, null, null);
            return c;

        } catch (Exception e) {
            Log.e("BIBLIO", e.getLocalizedMessage());
            Log.e("BIBLIO", e.getStackTrace().toString());
            return null;
        }
    }
}