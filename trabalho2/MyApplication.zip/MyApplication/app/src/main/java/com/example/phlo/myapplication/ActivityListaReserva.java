package com.example.phlo.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.phlo.myapplication.Banco.BibliotecaContract;
import com.example.phlo.myapplication.Banco.BibliotecaDbHelper;
import com.example.phlo.myapplication.Model.ParticipanteModel;
import com.example.phlo.myapplication.Model.ReservaModel;

import java.util.ArrayList;

public class ActivityListaReserva extends AppCompatActivity {
    private ListView listagem;
    private TextView txttitulo;
    private BibliotecaDbHelper dbhelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_reserva);
        listagem= (ListView)findViewById(R.id.listagem);
        Intent i = getIntent();
        txttitulo=(TextView)findViewById(R.id.txttitulo);
        if(i!=null) {
            try {
                int t = 0;
                String id = i.getStringExtra("id");
                int j=Integer.parseInt(id);
                ArrayList<String>NomeParticipante = new ArrayList<String>();
                dbhelper= new BibliotecaDbHelper(getBaseContext());
                SQLiteDatabase db = openOrCreateDatabase("Tabelas.db", Context.MODE_PRIVATE, null);
                ReservaModel reserva =dbhelper.reserva(j);
                txttitulo.setText(reserva.getLivronome());
                String sql = "SELECT * FROM ReservaModel where ReservaModel.tituloLivro="+reserva.getLivronome();
                Cursor c = db.rawQuery(sql, new String[]{});
                if (c.moveToFirst()) {
                    do {

                        NomeParticipante.add(c.getString(c.getColumnIndex(BibliotecaContract.Reserva.COLUMN_NAME_NomeParticipante)));
                        System.out.print(NomeParticipante.get(t));
                        t++;
                    } while (c.moveToNext());


                    db.close();

                }


                ArrayAdapter adapter = new ArrayAdapter(this,R.layout.lista_reserva,R.id.lista_parti,NomeParticipante);
                listagem.setAdapter(adapter);

            }
            catch (Exception e){
                Log.e("erro",e.getLocalizedMessage());
            }

        }

    }
}
