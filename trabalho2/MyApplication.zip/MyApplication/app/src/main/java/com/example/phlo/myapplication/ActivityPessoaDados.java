package com.example.phlo.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.StringBuilderPrinter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.phlo.myapplication.Banco.BibliotecaContract;
import com.example.phlo.myapplication.Banco.BibliotecaDbHelper;
import com.example.phlo.myapplication.Model.ParticipanteModel;

import java.util.Date;

public class ActivityPessoaDados extends AppCompatActivity {
    private TextView nome;
    private TextView email;
    private TextView dataentrada;
    private TextView datasaida;
    private BibliotecaDbHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pessoa_dados);
        StringBuilder sb= new StringBuilder();
        Intent i = getIntent();
        String id=i.getStringExtra("id");
        int j=Integer.parseInt(id);
        dbHelper = new BibliotecaDbHelper(getApplicationContext());
        nome=(TextView)findViewById(R.id.nome);
        email=(TextView)findViewById(R.id.email);
        dataentrada=(TextView)findViewById(R.id.entrada);
        datasaida=(TextView)findViewById(R.id.saida);

        ParticipanteAdapter parti = new ParticipanteAdapter(getApplicationContext(),null);
        ParticipanteModel participante =  parti.getParticipante(j);

        nome.setText(participante.getNome());
        email.setText(participante.getEmail());
        if(participante.getHoraEntrada()!=null) {
            dataentrada.setText(participante.getHoraEntrada());
        }
        if(participante.getHoraSaida()!=null) {
            datasaida.setText(participante.getHoraSaida());
        }
    }
}
